class Midterm{

    constructor (inputvariable) {

        var totalpoints = 0;

        function output_div2() {
            var btn = document.createElement("h1");        // Create a <button> element
            var t = document.createTextNode("Create DIV 2");       // Create a text node
            btn.appendChild(t);                                // Append the text to <button>
            document.getElementById('output_div2').appendChild(btn); 




        }

        function output_div3() {
            var btn = document.createElement("h1");        // Create a <button> element
            var t = document.createTextNode("Create DIV 3");       // Create a text node
            btn.appendChild(t);                                // Append the text to <button>
            document.getElementById('output_div3').appendChild(btn); 
        }

        function output_div4() {
            var btn = document.createElement("h1");        // Create a <button> element
            var t = document.createTextNode("Create DIV 4");       // Create a text node
            btn.appendChild(t);                                // Append the text to <button>
            document.getElementById('output_div4').appendChild(btn); 
        }

        function output_div5() {
            var btn = document.createElement("h1");        // Create a <button> element
            var t = document.createTextNode("Create DIV 5");       // Create a text node
            btn.appendChild(t);                                // Append the text to <button>
            document.getElementById('output_div5').appendChild(btn); 
        }

    }

}