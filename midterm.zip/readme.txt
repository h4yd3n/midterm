readme.txt

not much of an app. just went through the list and made random code

Couldn't get working:
1. OOP Application with class and constructor(), constructor takes at least one argument: + 25
10. Use of Object Sorting by Property Key: + 5
14. CRUD call to Database using PHP-MySQL: + 5
15. CRUD call that saves result of user interaction (vote, score, etc): + 5

Got working:
2. Use of map, filter, reduce (any two): + 5
3. AJAX-JSON to load data into app: + 5
4. Dynamic HTML elements using document.createElement(‘div’), etc. for min 5 elements: + 5
5. Use of dynamic image(s) with new Image() instantiation: + 5
6. Use of dynamic audio with new Audio() or document.getElementById(‘audio’): + 5
7. Use at least two Math methods, Math.random(), Math.floor(), etc.: + 5
8. Use of at least 3 array methods: splice(), slice(), push(), pop(), join(), shift(), unshift(): + 5
9. Use of at least 1 string method : charAt(), indexOf(), split(): + 5
11. Use of setTimeout() or setInterval() / clearInterval(): + 5
12. Distribution: FTP to Website: + 5
13. Distribution: Push to Github: + 5
16. Frontend: use of CSS Grid or Flexbox: + 5
17. Frontend: Overall appearance and use of styles / CSS: + 5
18. Technical communication: ReadMe.txt file that describes app: + 5
19. Technical communication: pseudo-code algorithm: + 5
20. Technical communication: public presentation of project (10 minutes): + 5

